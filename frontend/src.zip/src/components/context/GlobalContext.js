import { createContext } from "react";

const GlobalContext = createContext();
export default GlobalContext;