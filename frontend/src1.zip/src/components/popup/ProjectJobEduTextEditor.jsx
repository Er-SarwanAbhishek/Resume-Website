import { useState } from "react";
import ReactQuill from "react-quill"; // Import the Quill component
import "react-quill/dist/quill.snow.css"; // Import Quill's snow theme

const ProjectJobEduTextEditor = ({ previousValue, handleChange }) => {


  const modules = {
    toolbar: [
      [
        { list: "ordered" },
        { list: "bullet" },
        "bold",
        "italic",
        "underline",
        { color: [] },
        "link",
      ],
    ],
  };

  return (
    <div>
      <ReactQuill
        value={previousValue}
        onChange={handleChange}
        modules={modules}
        theme="snow"
        placeholder={previousValue}
      />
      
    </div>
  );
};

export default ProjectJobEduTextEditor;
